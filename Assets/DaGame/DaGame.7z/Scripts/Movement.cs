using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Movement : MonoBehaviour {
    const float RayDistance = 10f;
    [SerializeField] KeyCode forward, left, backwards, right;
    [SerializeField] KeyCode jump = KeyCode.Space;
    [SerializeField] float moveSpeed = 500f;
    [SerializeField] float jumpForce = 1000f;
    float groundCheckDist = 1f;
    Rigidbody rb;


    void Start() {
        rb = GetComponent<Rigidbody>();
    }

    void Update() {
        HandleInput();
        CheckRays();

    }

    void OnDrawGizmos() {
        Gizmos.color = Color.cyan;
        Gizmos.DrawRay(transform.position, transform.position + (transform.forward * RayDistance));
    }

    void CheckRays() {
        if(Physics.Raycast(transform.position, transform.forward, out RaycastHit hit, RayDistance)) {
        }

    }

    void HandleInput() {
        if(Input.GetKey(forward)) {
            Move(Forward);
        }
        if(Input.GetKey(backwards)) {
            Move(Backwards);
        }
        if(Input.GetKey(left)) {
            Move(Left);
        }
        if(Input.GetKey(right)) {
            Move(Right);
        }

        if(Input.GetKeyDown(jump)) {
            if(Physics.Raycast(transform.position, Vector3.down, groundCheckDist)) {
                rb.AddForce(Vector3.up * moveSpeed);
            }
        }
    }

    private void Move(Vector3 dir) {
        rb.AddForce(dir * moveSpeed * Time.deltaTime);
    }

    private Vector3 Forward => transform.forward;
    private Vector3 Backwards => -transform.forward;
    private Vector3 Left => -transform.right;
    private Vector3 Right => transform.right;
}
