using UnityEngine;

public class Trap : MonoBehaviour {
    [SerializeField] TrapEvent onTrapTriggered;
    [SerializeField] bool disableOnTrigger = true;

    void OnTriggerEnter(Collider other) {
        if(other.gameObject.layer == LayerMask.NameToLayer("Player")) {
            var data = new TrapData() {
                TriggeredPosition = transform.position
            };

            onTrapTriggered.TrapTriggered(data);
            if(disableOnTrigger) { gameObject.SetActive(false); }
        }
    }
}
