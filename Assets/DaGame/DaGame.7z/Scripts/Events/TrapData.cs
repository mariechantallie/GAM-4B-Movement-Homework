
using UnityEngine;

public class TrapData {
    public Vector3 TriggeredPosition { get; set; }
}
